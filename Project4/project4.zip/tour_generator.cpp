#include "tour_generator.h"
#include <iostream>
#include <iomanip>
#include <vector>
#include <list>
#include <stack>
#include <set>


TourGenerator::TourGenerator(const GeoDatabaseBase& geodb, const RouterBase& router)
{

}

TourGenerator::~TourGenerator()
{

}

std::vector<TourCommand> TourGenerator::generate_tour(const Stops& stops) const
{

}