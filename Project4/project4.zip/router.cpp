#include "router.h"

#include <iostream>
#include <iomanip>
#include <vector>
#include <list>
#include <stack>
#include <set>


Router::Router(const GeoDatabaseBase& geo_db)
{

}

Router::~Router()
{

}

std::vector<GeoPoint> Router::route(const GeoPoint& pt1, const GeoPoint& pt2) const
{

}